from flask_wtf import FlaskForm
from wtforms import TextAreaField
from wtforms import SubmitField


class FeedbackForm(FlaskForm):
    content = TextAreaField('Отзыв')
    submit = SubmitField('Отправить')
