from flask import Flask, render_template, redirect


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/')
def main():
    return render_template('main.html')


@app.route('/врачи')
def doctors():
    return render_template('doctors.html')


@app.route('/услуги')
def services():
    return render_template('services.html')


@app.route('/отзывы')
def feedbacks():
    return render_template('feedbacks.html')


@app.route('/адреса')
def addresses():
    return render_template('addresses.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
